# AXIOM — AI Image Generation Platform

> Claude prompt enhancement → FLUX image generation → Fidelity check

## Stack
- **Next.js 14** App Router + TypeScript
- **NextAuth.js** — Google OAuth + Email/Password
- **Prisma** + SQLite (dev) / PostgreSQL (prod)
- **Claude API** — prompt enhancement + fidelity analysis
- **fal.ai FLUX** — image generation  
- **Cloudflare R2** — image storage (optional in dev)
- **TanStack Query** + **Zustand** — state
- **Tailwind CSS** — styling

---

## ⚡ Quick Start (5 minutes)

### Prerequisites
- Node.js 20+
- API keys: [Anthropic](https://console.anthropic.com) + [fal.ai](https://fal.ai/dashboard/keys)

### Setup
```bash
# 1. Install
npm install

# 2. Environment
cp .env.example .env.local
# → Edit .env.local and fill in ANTHROPIC_API_KEY, FAL_KEY, NEXTAUTH_SECRET

# 3. Database
npx prisma db push
npx tsx prisma/seed.ts

# 4. Run
npm run dev
```

Open **http://localhost:3000**

Login: `demo@axiom.ai` / `password123`

---

## Environment Variables

```bash
# Required
NEXTAUTH_SECRET=          # openssl rand -base64 32
ANTHROPIC_API_KEY=        # sk-ant-api03-...
FAL_KEY=                  # from fal.ai/dashboard/keys

# Optional (Google OAuth)
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=

# Optional (Image storage — uses fal.ai URLs in dev without this)
R2_ACCOUNT_ID=
R2_ACCESS_KEY_ID=
R2_SECRET_ACCESS_KEY=
R2_BUCKET_NAME=
R2_PUBLIC_URL=
```

---

## Project Structure

```
src/
├── app/
│   ├── (auth)/login/            ← Login page
│   ├── (dashboard)/
│   │   ├── layout.tsx           ← Auth guard + sidebar
│   │   ├── studio/page.tsx      ← Main 3-col generation UI
│   │   ├── gallery/page.tsx     ← Infinite scroll gallery
│   │   └── settings/page.tsx   ← Account + usage
│   ├── api/
│   │   ├── auth/[...nextauth]/  ← Auth handler
│   │   ├── generate/            ← POST: full pipeline
│   │   ├── generations/         ← GET list + [id] CRUD
│   │   └── credits/             ← GET quota status
│   ├── layout.tsx               ← Root layout + fonts
│   └── providers.tsx            ← Session + React Query
│
├── components/
│   └── ui/Sidebar.tsx
│
├── hooks/
│   ├── useGenerate.ts           ← Pipeline state machine
│   ├── useCredits.ts            ← Credits polling
│   └── useGallery.ts            ← Infinite query + mutations
│
├── lib/
│   ├── auth.ts                  ← NextAuth config
│   ├── claude.ts                ← Enhance + fidelity
│   ├── credits.ts               ← Quota management
│   ├── db.ts                    ← Prisma singleton
│   ├── fal.ts                   ← fal.ai FLUX client
│   └── storage.ts               ← R2 upload
│
└── types/index.ts               ← Shared types

prisma/
├── schema.prisma                ← Full schema
└── seed.ts                      ← Demo user
```

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/generate` | Full pipeline — returns image + fidelity |
| `GET`  | `/api/generations?page=1&favorites=true` | Paginated gallery |
| `GET`  | `/api/generations/:id` | Single generation |
| `PATCH`| `/api/generations/:id` | Toggle favorite |
| `DELETE`| `/api/generations/:id` | Delete + remove from storage |
| `GET`  | `/api/credits` | Remaining daily quota |

---

## Daily Credit Limits

| Tier | Limit |
|------|-------|
| FREE | 5/day |
| PRO  | 100/day |
| TEAM | 500/day |

---

## Production Deployment

**Vercel (Frontend)**
```bash
# Set all env vars in Vercel dashboard
# Change DATABASE_URL to PostgreSQL
# Update prisma/schema.prisma provider to "postgresql"
```

**Database (PostgreSQL)**
```bash
# Supabase, Neon, or Railway — free tiers available
DATABASE_URL="postgresql://..."
```

**Image Storage (Cloudflare R2)**
```bash
# Create bucket → fill R2_* env vars
# Without R2, images are served directly from fal.ai URLs
```

---

## Phase 2 Roadmap

- [ ] Stripe subscriptions (FREE → PRO → TEAM)
- [ ] Public gallery + community feed  
- [ ] Batch generation (4 images at once)
- [ ] Model selector (FLUX Dev, SDXL, SD3)
- [ ] Developer API with key management
- [ ] Team workspace + shared billing
