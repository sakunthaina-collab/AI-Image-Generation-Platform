import {
  S3Client,
  PutObjectCommand,
  DeleteObjectCommand,
} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

// ── Cloudflare R2 client ──────────────────────────────────────
const r2 = new S3Client({
  region: "auto",
  endpoint: `https://${process.env.R2_ACCOUNT_ID!}.r2.cloudflarestorage.com`,
  credentials: {
    accessKeyId:     process.env.R2_ACCESS_KEY_ID!,
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY!,
  },
});

const BUCKET = process.env.R2_BUCKET_NAME!;
const PUBLIC_URL = process.env.R2_PUBLIC_URL!;

// ── Upload image from URL (from fal.ai) to R2 ────────────────
export async function uploadImageFromUrl(
  sourceUrl: string,
  userId:    string,
  genId:     string
): Promise<{ imageUrl: string; thumbnailUrl: string }> {
  const res = await fetch(sourceUrl);
  if (!res.ok) throw new Error("Failed to fetch image from fal.ai");

  const buffer      = Buffer.from(await res.arrayBuffer());
  const contentType = res.headers.get("content-type") || "image/jpeg";
  const ext         = contentType.includes("png") ? "png" : "jpg";

  // Full resolution
  const fullKey = `generations/${userId}/${genId}/image.${ext}`;
  await r2.send(
    new PutObjectCommand({
      Bucket:      BUCKET,
      Key:         fullKey,
      Body:        buffer,
      ContentType: contentType,
      CacheControl: "public, max-age=31536000, immutable",
    })
  );

  // TODO: generate thumbnail with sharp in production
  const thumbKey = fullKey; // same for now

  return {
    imageUrl:    `${PUBLIC_URL}/${fullKey}`,
    thumbnailUrl: `${PUBLIC_URL}/${thumbKey}`,
  };
}

// ── Delete image from R2 ─────────────────────────────────────
export async function deleteImage(imageUrl: string): Promise<void> {
  const key = imageUrl.replace(`${PUBLIC_URL}/`, "");
  await r2.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: key }));
}

// ── Presigned URL for direct browser upload (future use) ─────
export async function getPresignedUploadUrl(
  key:         string,
  contentType: string
): Promise<string> {
  return getSignedUrl(
    r2,
    new PutObjectCommand({ Bucket: BUCKET, Key: key, ContentType: contentType }),
    { expiresIn: 300 }
  );
}
