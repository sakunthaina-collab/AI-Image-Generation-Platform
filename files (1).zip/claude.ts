import Anthropic from "@anthropic-ai/sdk";
import { z } from "zod";

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
});

// ── Schema สำหรับ response จาก Claude ──
const EnhanceResponseSchema = z.object({
  enhanced:      z.string(),
  negative:      z.string(),
  key_additions: z.array(z.string()),
});

const FidelityResponseSchema = z.object({
  score:    z.number().min(0).max(100),
  verdict:  z.string(),
  criteria: z.array(z.object({
    name:  z.string(),
    score: z.number().min(0).max(100),
    note:  z.string(),
  })),
  suggestions: z.array(z.string()),
});

export type EnhanceResult  = z.infer<typeof EnhanceResponseSchema>;
export type FidelityResult = z.infer<typeof FidelityResponseSchema>;
export type FidelityStrategy = "PRESERVE" | "ENRICH" | "STRICT";

// ── STRATEGY PROMPTS ──────────────────────────────────────────
const STRATEGY_INSTRUCTIONS: Record<FidelityStrategy, string> = {
  PRESERVE: `STRATEGY "Preserve Intent":
- Add ONLY technical quality tags and lighting descriptors
- DO NOT change the subject, action, or setting
- Keep the core description verbatim at the start`,

  ENRICH: `STRATEGY "Enrich Details":
- Expand with: specific lighting conditions, textures, atmosphere,
  camera angle, color palette, artistic style
- Maintain the original subject and mood exactly`,

  STRICT: `STRATEGY "Strict Literal":
- Add ONLY 3–5 quality marker tags at the very end
  (e.g., "highly detailed, 8K, masterpiece")
- Do NOT alter anything else`,
};

// ── ENHANCE PROMPT ────────────────────────────────────────────
export async function enhancePrompt(
  rawPrompt: string,
  strategy: FidelityStrategy = "PRESERVE"
): Promise<EnhanceResult> {
  const systemPrompt = `You are an expert at converting raw image descriptions into
optimized FLUX diffusion model prompts.

${STRATEGY_INSTRUCTIONS[strategy]}

Return ONLY a JSON object — no markdown, no explanation:
{
  "enhanced": "full enhanced prompt, comma-separated",
  "negative": "suggested negative prompt",
  "key_additions": ["addition 1", "addition 2", "addition 3"]
}`;

  const message = await client.messages.create({
    model:      "claude-sonnet-4-6",
    max_tokens: 600,
    system:     systemPrompt,
    messages:   [{ role: "user", content: rawPrompt }],
  });

  const text  = (message.content[0] as { text: string }).text;
  const clean = text.replace(/```json|```/g, "").trim();
  return EnhanceResponseSchema.parse(JSON.parse(clean));
}

// ── FIDELITY CHECK ────────────────────────────────────────────
export async function checkFidelity(
  rawPrompt:      string,
  enhancedPrompt: string,
): Promise<FidelityResult> {
  const systemPrompt = `You are a prompt fidelity analyzer for AI image generation.
Analyze the PROMPT CHAIN to detect drift between the user's original intent
and what FLUX likely generated from the enhanced prompt.

Return ONLY valid JSON:
{
  "score": 0-100,
  "verdict": "High Fidelity" | "Moderate Fidelity" | "Low Fidelity",
  "criteria": [
    { "name": "Subject Accuracy",    "score": 0-100, "note": "..." },
    { "name": "Mood & Atmosphere",   "score": 0-100, "note": "..." },
    { "name": "Style Alignment",     "score": 0-100, "note": "..." },
    { "name": "Detail Preservation", "score": 0-100, "note": "..." }
  ],
  "suggestions": [
    "actionable improvement 1",
    "actionable improvement 2",
    "actionable improvement 3"
  ]
}`;

  const userMsg = `ORIGINAL: "${rawPrompt}"\n\nENHANCED SENT TO FLUX: "${enhancedPrompt}"`;

  const message = await client.messages.create({
    model:      "claude-sonnet-4-6",
    max_tokens: 600,
    system:     systemPrompt,
    messages:   [{ role: "user", content: userMsg }],
  });

  const text  = (message.content[0] as { text: string }).text;
  const clean = text.replace(/```json|```/g, "").trim();
  return FidelityResponseSchema.parse(JSON.parse(clean));
}
