import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        mono: ["var(--font-dm-mono)", "monospace"],
        display: ["var(--font-bebas)", "sans-serif"],
        serif: ["var(--font-lora)", "serif"],
      },
      colors: {
        axiom: {
          void: "#07070a",
          deep: "#0d0d13",
          surface: "#151520",
          lift: "#1d1d2a",
          amber: "#f0a500",
          "amber-2": "#ffc94a",
          teal: "#00c9b1",
          snow: "#f0eee9",
        },
      },
      keyframes: {
        "fade-up": {
          from: { opacity: "0", transform: "translateY(12px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        shimmer: {
          "0%, 100%": { backgroundPosition: "0% 50%" },
          "50%": { backgroundPosition: "100% 50%" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.4s ease",
        shimmer: "shimmer 3s ease infinite",
      },
    },
  },
  plugins: [],
};
export default config;
