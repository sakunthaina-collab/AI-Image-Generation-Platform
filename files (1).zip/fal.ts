// ── fal.ai FLUX integration ───────────────────────────────────
export type ImageSize =
  | "square_hd"
  | "landscape_4_3"
  | "landscape_16_9"
  | "portrait_4_3"
  | "portrait_16_9";

export interface GenerateOptions {
  prompt:         string;
  negativePrompt?: string;
  imageSize?:     ImageSize;
  steps?:         number;
  seed?:          number;
}

export interface GenerateResult {
  imageUrl:    string;
  seed:        number;
  requestId:   string;
  genTimeMs:   number;
}

export async function generateImage(
  options: GenerateOptions
): Promise<GenerateResult> {
  const {
    prompt,
    negativePrompt = "",
    imageSize = "square_hd",
    steps = 8,
    seed = Math.floor(Math.random() * 2147483647),
  } = options;

  const t0 = Date.now();

  // ── Submit job ────────────────────────────────────────────
  const submitRes = await fetch(
    "https://queue.fal.run/fal-ai/flux/schnell",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization:  `Key ${process.env.FAL_KEY}`,
      },
      body: JSON.stringify({
        prompt,
        negative_prompt:         negativePrompt,
        image_size:               imageSize,
        num_inference_steps:      steps,
        seed,
        num_images:               1,
        enable_safety_checker:    true,
      }),
    }
  );

  if (!submitRes.ok) {
    const err = await submitRes.json().catch(() => ({}));
    throw new Error(
      (err as { detail?: string }).detail ||
      `fal.ai submit failed: ${submitRes.status}`
    );
  }

  const { request_id: requestId } = await submitRes.json() as { request_id: string };

  // ── Poll for result ───────────────────────────────────────
  for (let attempt = 0; attempt < 60; attempt++) {
    await delay(1500);

    const pollRes = await fetch(
      `https://queue.fal.run/fal-ai/flux/schnell/requests/${requestId}`,
      { headers: { Authorization: `Key ${process.env.FAL_KEY}` } }
    );

    if (!pollRes.ok) continue;

    const status = await pollRes.json() as {
      status: string;
      output?: { images?: Array<{ url: string }> };
      error?: string;
    };

    if (status.status === "COMPLETED") {
      const imageUrl = status.output?.images?.[0]?.url;
      if (!imageUrl) throw new Error("fal.ai returned no image URL");
      return {
        imageUrl,
        seed,
        requestId,
        genTimeMs: Date.now() - t0,
      };
    }

    if (status.status === "FAILED") {
      throw new Error(`fal.ai job failed: ${status.error ?? "unknown"}`);
    }
  }

  throw new Error("fal.ai timed out after 90 seconds");
}

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
