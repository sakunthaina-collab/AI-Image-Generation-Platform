import { useInfiniteQuery, useMutation, useQueryClient } from "@tanstack/react-query";

interface GalleryItem {
  id:           string;
  imageUrl:     string;
  thumbnailUrl: string | null;
  rawPrompt:    string;
  fidelityScore: number | null;
  isFavorite:   boolean;
  createdAt:    string;
  strategy:     string;
}

async function fetchGallery({ pageParam = 1, favOnly = false }) {
  const url = `/api/generations?page=${pageParam}&limit=20${favOnly ? "&favorites=true" : ""}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("Failed to fetch gallery");
  return res.json() as Promise<{
    items: GalleryItem[];
    pagination: { page: number; pages: number; total: number };
  }>;
}

export function useGallery(favOnly = false) {
  return useInfiniteQuery({
    queryKey:     ["gallery", favOnly],
    queryFn:      ({ pageParam }) => fetchGallery({ pageParam, favOnly }),
    initialPageParam: 1,
    getNextPageParam: (last) =>
      last.pagination.page < last.pagination.pages
        ? last.pagination.page + 1
        : undefined,
  });
}

export function useToggleFavorite() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, isFavorite }: { id: string; isFavorite: boolean }) =>
      fetch(`/api/generations/${id}`, {
        method:  "PATCH",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ isFavorite }),
      }).then((r) => r.json()),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["gallery"] });
    },
  });
}

export function useDeleteGeneration() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) =>
      fetch(`/api/generations/${id}`, { method: "DELETE" }).then((r) => r.json()),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["gallery"] });
    },
  });
}
