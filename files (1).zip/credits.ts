import { db } from "@/lib/db";
import { Tier } from "@prisma/client";

const DAILY_LIMITS: Record<Tier, number> = {
  FREE:  5,
  PRO:   100,
  TEAM:  500,
  ADMIN: 99999,
};

// ── Check & deduct one credit ─────────────────────────────────
export async function useCredit(userId: string): Promise<void> {
  const user = await db.user.findUniqueOrThrow({
    where: { id: userId },
    select: { tier: true, creditsUsed: true, creditsReset: true },
  });

  // Reset counter if new day
  const now      = new Date();
  const resetDay = user.creditsReset.toDateString();
  const today    = now.toDateString();

  let creditsUsed = user.creditsUsed;
  if (resetDay !== today) {
    creditsUsed = 0;
    await db.user.update({
      where: { id: userId },
      data:  { creditsUsed: 0, creditsReset: now },
    });
  }

  const limit = DAILY_LIMITS[user.tier];
  if (creditsUsed >= limit) {
    throw new Error(
      `Daily limit reached (${limit} generations). Upgrade for more.`
    );
  }

  await db.user.update({
    where: { id: userId },
    data:  { creditsUsed: { increment: 1 } },
  });
}

// ── Get remaining credits ─────────────────────────────────────
export async function getCredits(userId: string) {
  const user = await db.user.findUniqueOrThrow({
    where:  { id: userId },
    select: { tier: true, creditsUsed: true, creditsReset: true },
  });

  const now      = new Date();
  const resetDay = user.creditsReset.toDateString();
  const today    = now.toDateString();
  const used     = resetDay !== today ? 0 : user.creditsUsed;
  const limit    = DAILY_LIMITS[user.tier];

  return {
    used,
    limit,
    remaining: Math.max(0, limit - used),
    tier: user.tier,
    resetsAt: resetDay !== today ? now : user.creditsReset,
  };
}
