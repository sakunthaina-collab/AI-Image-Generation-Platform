import { useState, useCallback } from "react";

export type GenerationStage =
  | "idle" | "enhancing" | "generating" | "checking" | "uploading" | "done" | "error";

export interface GenerationResult {
  id:             string;
  imageUrl:       string;
  enhancedPrompt: string;
  keyAdditions:   string[];
  fidelity: {
    score:    number;
    verdict:  string;
    criteria: Array<{ name: string; score: number; note: string }>;
    suggestions: string[];
  };
  seed:     number;
  genTimeMs: number;
}

export interface GeneratePayload {
  rawPrompt:      string;
  negativePrompt?: string;
  strategy:       "PRESERVE" | "ENRICH" | "STRICT";
  imageSize:      string;
  steps:          number;
}

export function useGenerate() {
  const [stage,   setStage]   = useState<GenerationStage>("idle");
  const [result,  setResult]  = useState<GenerationResult | null>(null);
  const [error,   setError]   = useState<string | null>(null);
  const [progress, setProgress] = useState(0);

  const generate = useCallback(async (payload: GeneratePayload) => {
    setStage("enhancing");
    setError(null);
    setResult(null);
    setProgress(10);

    try {
      // Animate progress while waiting
      const progressTimer = setInterval(() => {
        setProgress((p) => Math.min(p + 2, 88));
      }, 800);

      const res = await fetch("/api/generate", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(payload),
      });

      clearInterval(progressTimer);

      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: "Unknown error" }));
        throw new Error(err.error ?? `HTTP ${res.status}`);
      }

      setProgress(95);
      const data: GenerationResult = await res.json();
      setProgress(100);
      setResult(data);
      setStage("done");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Generation failed");
      setStage("error");
      setProgress(0);
    }
  }, []);

  const reset = useCallback(() => {
    setStage("idle");
    setResult(null);
    setError(null);
    setProgress(0);
  }, []);

  return { stage, result, error, progress, generate, reset };
}
