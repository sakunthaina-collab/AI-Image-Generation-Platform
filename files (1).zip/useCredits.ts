import { useQuery } from "@tanstack/react-query";

interface Credits {
  used:      number;
  limit:     number;
  remaining: number;
  tier:      string;
  resetsAt:  string;
}

export function useCredits() {
  return useQuery<Credits>({
    queryKey: ["credits"],
    queryFn:  () => fetch("/api/credits").then((r) => r.json()),
    refetchInterval: 60_000, // refresh every minute
    staleTime: 30_000,
  });
}
