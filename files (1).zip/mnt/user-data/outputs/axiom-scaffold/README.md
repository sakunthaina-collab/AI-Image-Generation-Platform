# AXIOM — AI Image Generation Platform

> Claude prompt enhancement → FLUX image generation → Fidelity check

## Stack
- **Next.js 14** (App Router) + TypeScript
- **NextAuth.js** — Google OAuth + Email/Password
- **Prisma** + PostgreSQL
- **Claude API** — prompt enhancement + fidelity analysis
- **fal.ai FLUX** — image generation
- **Cloudflare R2** — image storage
- **TanStack Query** — server state
- **Tailwind CSS** — styling

---

## Quick Start

### 1. Prerequisites
- Node.js 20+
- Docker (for local Postgres)
- API keys: Anthropic, fal.ai, Google OAuth

### 2. Install
```bash
npm install
```

### 3. Environment
```bash
cp .env.example .env.local
# Fill in all values
```

### 4. Start services
```bash
docker-compose up -d   # starts postgres + redis
```

### 5. Database
```bash
npm run db:migrate     # run migrations
npm run db:studio      # optional: Prisma Studio UI
```

### 6. Dev server
```bash
npm run dev
# → http://localhost:3000
```

---

## Project Structure

```
src/
├── app/
│   ├── (auth)/login/          ← Login page
│   ├── (dashboard)/
│   │   ├── layout.tsx         ← Protected layout + sidebar
│   │   ├── studio/page.tsx    ← Main generation UI
│   │   └── gallery/page.tsx   ← Image history
│   ├── api/
│   │   ├── auth/[...nextauth] ← NextAuth handler
│   │   ├── generate/          ← POST: full pipeline
│   │   ├── generations/       ← GET list + [id] CRUD
│   │   └── credits/           ← GET remaining credits
│   ├── layout.tsx             ← Root layout + providers
│   └── providers.tsx          ← Session + React Query
│
├── hooks/
│   ├── useGenerate.ts         ← Pipeline state machine
│   ├── useCredits.ts          ← Credits polling
│   └── useGallery.ts          ← Infinite gallery + mutations
│
└── lib/
    ├── auth.ts                ← NextAuth config
    ├── claude.ts              ← Enhance + fidelity check
    ├── credits.ts             ← Quota management
    ├── db.ts                  ← Prisma singleton
    ├── fal.ts                 ← fal.ai FLUX client
    └── storage.ts             ← Cloudflare R2 upload

prisma/
└── schema.prisma              ← Full DB schema
```

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/generate` | Full pipeline: enhance → generate → check |
| GET | `/api/generations` | Paginated gallery (`?page=1&limit=20&favorites=true`) |
| GET | `/api/generations/:id` | Single generation detail |
| PATCH | `/api/generations/:id` | Toggle favorite |
| DELETE | `/api/generations/:id` | Delete + remove from R2 |
| GET | `/api/credits` | Remaining daily credits |

---

## Daily Credit Limits

| Tier | Generations/day |
|------|----------------|
| FREE | 5 |
| PRO | 100 |
| TEAM | 500 |

---

## Phase 2 Roadmap
- [ ] Stripe subscription (FREE → PRO → TEAM)
- [ ] Public gallery + community feed
- [ ] Batch generation (multiple images)
- [ ] Model selector (FLUX Dev, SDXL, SD3)
- [ ] Developer API keys
- [ ] Team workspace + shared billing
