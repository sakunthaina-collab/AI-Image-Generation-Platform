"use client";

import { useState } from "react";
import { useGenerate } from "@/hooks/useGenerate";
import { useCredits } from "@/hooks/useCredits";
import { useQueryClient } from "@tanstack/react-query";

const QUICK_PROMPTS = [
  { label: "Cyberpunk Alley",  text: "Neon-lit cyberpunk alley, rain-slicked pavement, holographic signs" },
  { label: "Ocean Ruins",      text: "Underwater ruins of a lost city, bioluminescent fish, shafts of sunlight" },
  { label: "Desert Canyon",    text: "Surreal desert canyon, towering rock formations, crimson sunset sky" },
  { label: "Winter Shrine",    text: "Snow-covered Japanese shrine at night, red lanterns, heavy snowfall" },
  { label: "Magic Library",    text: "Ancient library with floating books, golden dust particles, mystical glow" },
  { label: "Space Station",    text: "Abandoned space station, star field beyond cracked viewport, zero gravity" },
];

const STRATEGIES = [
  { value: "PRESERVE", label: "Preserve Intent",  desc: "Adds only quality tags, keeps subject verbatim" },
  { value: "ENRICH",   label: "Enrich Details",   desc: "Expands lighting, atmosphere, textures" },
  { value: "STRICT",   label: "Strict Literal",   desc: "Minimal change — closest to raw input" },
] as const;

export default function StudioPage() {
  const [rawPrompt,  setRawPrompt]  = useState("");
  const [negPrompt,  setNegPrompt]  = useState("");
  const [strategy,   setStrategy]   = useState<"PRESERVE"|"ENRICH"|"STRICT">("PRESERVE");
  const [imageSize,  setImageSize]  = useState("square_hd");
  const [steps,      setSteps]      = useState(8);

  const { stage, result, error, progress, generate, reset } = useGenerate();
  const { data: credits } = useCredits();
  const qc = useQueryClient();

  const handleRun = async () => {
    if (!rawPrompt.trim()) return;
    await generate({ rawPrompt, negativePrompt: negPrompt, strategy, imageSize, steps });
    qc.invalidateQueries({ queryKey: ["gallery"] });
    qc.invalidateQueries({ queryKey: ["credits"] });
  };

  const isRunning = stage !== "idle" && stage !== "done" && stage !== "error";

  return (
    <div className="grid grid-cols-[320px_1fr_280px] h-full overflow-hidden">

      {/* ── COL 1: INPUT ── */}
      <aside className="border-r border-white/7 bg-axiom-deep flex flex-col overflow-hidden">
        <div className="p-5 border-b border-white/7">
          <p className="text-[10px] tracking-[0.3em] text-amber-500 uppercase mb-1">01 — Prompt</p>
          <h2 className="font-serif italic text-lg text-axiom-snow">Describe your vision</h2>
        </div>

        <div className="flex-1 overflow-y-auto p-5 flex flex-col gap-4">
          {/* Raw prompt */}
          <div>
            <label className="block text-[9px] tracking-[0.3em] text-white/30 uppercase mb-2">
              Raw Prompt
            </label>
            <textarea
              value={rawPrompt}
              onChange={(e) => setRawPrompt(e.target.value)}
              placeholder="A lone lighthouse on a volcanic cliff at dusk..."
              rows={5}
              className="w-full bg-axiom-surface border border-white/7 rounded text-axiom-snow
                         font-mono text-[13px] p-3 resize-none outline-none leading-relaxed
                         focus:border-amber-500/40 focus:ring-2 focus:ring-amber-500/10
                         placeholder:italic placeholder:text-white/20 transition"
            />
            <div className="flex justify-end mt-1 text-[10px] text-white/20">
              {rawPrompt.length}/500
            </div>
          </div>

          {/* Quick prompts */}
          <div>
            <label className="block text-[9px] tracking-[0.3em] text-white/30 uppercase mb-2">
              Quick Start
            </label>
            <div className="flex flex-wrap gap-1.5">
              {QUICK_PROMPTS.map((qp) => (
                <button
                  key={qp.label}
                  onClick={() => setRawPrompt(qp.text)}
                  className="text-[10px] px-2.5 py-1 border border-white/10 rounded-full
                             text-white/40 hover:border-amber-500 hover:text-amber-500
                             hover:bg-amber-500/8 transition"
                >
                  {qp.label}
                </button>
              ))}
            </div>
          </div>

          {/* Negative prompt */}
          <div>
            <label className="block text-[9px] tracking-[0.3em] text-white/30 uppercase mb-2">
              Negative Prompt
            </label>
            <textarea
              value={negPrompt}
              onChange={(e) => setNegPrompt(e.target.value)}
              placeholder="blurry, watermark, low quality..."
              rows={2}
              className="w-full bg-axiom-surface border border-white/7 rounded font-mono
                         text-[12px] text-white/50 p-3 resize-none outline-none
                         focus:border-white/15 placeholder:text-white/20 transition"
            />
          </div>

          {/* Strategy */}
          <div>
            <label className="block text-[9px] tracking-[0.3em] text-white/30 uppercase mb-2">
              Fidelity Strategy
            </label>
            <div className="flex flex-col gap-1.5">
              {STRATEGIES.map((s) => (
                <label
                  key={s.value}
                  className={`flex gap-3 p-3 rounded border cursor-pointer transition
                    ${strategy === s.value
                      ? "border-amber-500/40 bg-amber-500/8"
                      : "border-white/7 hover:border-white/15"}`}
                >
                  <input
                    type="radio"
                    name="strategy"
                    value={s.value}
                    checked={strategy === s.value}
                    onChange={() => setStrategy(s.value)}
                    className="mt-0.5 accent-amber-500"
                  />
                  <div>
                    <div className="text-[11px] text-axiom-snow">{s.label}</div>
                    <div className="text-[10px] text-white/35 mt-0.5">{s.desc}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Size + Steps */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[9px] tracking-[0.3em] text-white/30 uppercase mb-2">
                Size
              </label>
              <select
                value={imageSize}
                onChange={(e) => setImageSize(e.target.value)}
                className="w-full bg-axiom-surface border border-white/7 rounded font-mono
                           text-[12px] text-axiom-snow px-3 py-2 outline-none
                           focus:border-amber-500/40 transition appearance-none cursor-pointer"
              >
                <option value="square_hd">1024² (Square)</option>
                <option value="landscape_16_9">16:9 Wide</option>
                <option value="landscape_4_3">4:3 Land</option>
                <option value="portrait_16_9">9:16 Tall</option>
              </select>
            </div>
            <div>
              <label className="block text-[9px] tracking-[0.3em] text-white/30 uppercase mb-2">
                Steps: {steps}
              </label>
              <input
                type="range" min={4} max={12} value={steps}
                onChange={(e) => setSteps(Number(e.target.value))}
                className="w-full mt-2 accent-amber-500"
              />
            </div>
          </div>
        </div>

        {/* Run button */}
        <div className="p-4 border-t border-white/7">
          {credits && (
            <div className="flex justify-between text-[10px] text-white/30 mb-2 font-mono">
              <span>Credits: {credits.remaining}/{credits.limit}</span>
              <span className="capitalize text-amber-500/70">{credits.tier}</span>
            </div>
          )}
          <button
            onClick={handleRun}
            disabled={isRunning || !rawPrompt.trim() || credits?.remaining === 0}
            className="w-full py-3.5 bg-amber-500 rounded font-display text-lg
                       tracking-wider text-black transition
                       hover:bg-amber-400 hover:shadow-[0_6px_28px_rgba(240,165,0,0.4)]
                       disabled:bg-axiom-surface disabled:text-white/20 disabled:cursor-not-allowed
                       relative overflow-hidden"
          >
            {isRunning ? (
              <span className="flex items-center justify-center gap-2">
                <span className="w-4 h-4 border-2 border-black/20 border-t-black rounded-full animate-spin" />
                Running... {progress}%
              </span>
            ) : "▶ RUN PIPELINE"}
          </button>
          <div className="text-center text-[10px] text-white/20 mt-2 font-mono">⌘↵ to run</div>
        </div>
      </aside>

      {/* ── COL 2: CANVAS ── */}
      <main className="flex flex-col bg-axiom-void overflow-hidden">
        <div className="flex-1 flex items-center justify-center p-10 relative">

          {/* Empty */}
          {stage === "idle" && !result && (
            <div className="text-center animate-fade-up">
              <div className="font-display text-8xl text-amber-500/6 tracking-widest mb-4">AXIOM</div>
              <p className="font-serif italic text-xl text-white/25">Canvas ready</p>
              <p className="text-[11px] text-white/12 mt-2 font-mono tracking-wider max-w-xs">
                Configure your prompt and run the pipeline
              </p>
            </div>
          )}

          {/* Loading */}
          {isRunning && (
            <div className="flex flex-col items-center gap-5 animate-fade-up">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-amber-300 to-amber-600
                              animate-pulse shadow-[0_0_40px_rgba(240,165,0,0.3)]" />
              <div className="font-display text-5xl text-white/60">{progress}<span className="text-2xl">%</span></div>
              <div className="text-[10px] tracking-[0.35em] text-amber-500 uppercase font-mono animate-pulse">
                {stage === "enhancing" ? "Claude enhancing prompt" : "FLUX generating image"}
              </div>
              <div className="w-60 h-0.5 bg-axiom-surface rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-amber-500 to-amber-300 transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          {/* Error */}
          {stage === "error" && error && (
            <div className="max-w-sm text-center animate-fade-up">
              <div className="text-red-400 text-4xl mb-3">⚠</div>
              <p className="text-red-400/70 font-mono text-sm">{error}</p>
              <button
                onClick={reset}
                className="mt-4 px-4 py-2 border border-white/15 rounded font-mono text-[11px]
                           text-white/40 hover:text-white hover:border-white/30 transition"
              >
                Try again
              </button>
            </div>
          )}

          {/* Result */}
          {result && (
            <div className="relative rounded-lg overflow-hidden shadow-[0_24px_80px_rgba(0,0,0,0.9)]
                            border border-white/10 max-w-2xl w-full animate-fade-up group">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={result.imageUrl} alt="Generated" className="w-full block" />

              {/* Hover overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent
                              opacity-0 group-hover:opacity-100 transition-opacity p-4
                              flex items-end justify-between">
                <span className="font-mono text-[10px] text-white/40">seed: {result.seed}</span>
                <div className="flex gap-2">
                  <a
                    href={result.imageUrl}
                    download
                    className="px-3 py-1.5 bg-white/10 backdrop-blur border border-white/20
                               rounded-full text-white text-[10px] font-mono hover:border-amber-500
                               hover:text-amber-400 transition"
                  >
                    ↓ Save
                  </a>
                  <button
                    onClick={() => { reset(); setRawPrompt(rawPrompt); }}
                    className="px-3 py-1.5 bg-white/10 backdrop-blur border border-white/20
                               rounded-full text-white text-[10px] font-mono hover:border-amber-500
                               hover:text-amber-400 transition"
                  >
                    ↻ Remix
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Meta bar */}
        {result && (
          <div className="border-t border-white/7 bg-axiom-deep px-6 py-3
                          flex flex-wrap gap-5">
            {[
              ["Model", "FLUX.1-schnell"],
              ["Size",  imageSize],
              ["Steps", steps],
              ["Time",  `${(result.genTimeMs / 1000).toFixed(1)}s`],
              ["Seed",  result.seed],
            ].map(([k, v]) => (
              <div key={String(k)}>
                <div className="text-[8px] tracking-[0.3em] text-white/25 uppercase">{k}</div>
                <div className="text-[11px] font-mono text-white/60">{v}</div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* ── COL 3: FIDELITY ── */}
      <aside className="border-l border-white/7 bg-axiom-deep flex flex-col overflow-y-auto">
        <div className="p-5 border-b border-white/7">
          <p className="text-[10px] tracking-[0.3em] text-amber-500 uppercase mb-1">03 — Fidelity</p>
          <h2 className="font-serif italic text-lg text-axiom-snow">Prompt accuracy</h2>
        </div>

        {!result ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-3 p-6 text-center">
            <div className="text-4xl opacity-15">🎯</div>
            <p className="text-[11px] font-mono text-white/20 tracking-wider max-w-[180px] leading-6">
              Fidelity analysis appears after generation
            </p>
          </div>
        ) : (
          <div className="p-5 flex flex-col gap-5">
            {/* Score ring */}
            <div className="flex flex-col items-center gap-3">
              <div className="relative w-24 h-24">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 90 90">
                  <circle cx="45" cy="45" r="40" fill="none" stroke="currentColor"
                    strokeWidth="6" className="text-axiom-surface"/>
                  <circle cx="45" cy="45" r="40" fill="none"
                    stroke={result.fidelity.score >= 75 ? "#00c9b1" : result.fidelity.score >= 50 ? "#f0a500" : "#ff5050"}
                    strokeWidth="6" strokeLinecap="round"
                    strokeDasharray="251"
                    strokeDashoffset={251 - (result.fidelity.score / 100) * 251}
                    className="transition-all duration-1000"/>
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="font-display text-3xl text-axiom-snow">{result.fidelity.score}</span>
                  <span className="text-[8px] tracking-widest text-white/30 font-mono">FIDELITY</span>
                </div>
              </div>
              <span className={`text-[10px] tracking-wider px-3 py-1 rounded-full border font-mono ${
                result.fidelity.score >= 75
                  ? "text-teal-400 border-teal-400/30 bg-teal-400/8"
                  : result.fidelity.score >= 50
                  ? "text-amber-400 border-amber-400/30 bg-amber-400/8"
                  : "text-red-400 border-red-400/30 bg-red-400/8"
              }`}>{result.fidelity.verdict}</span>
            </div>

            {/* Criteria */}
            <div className="flex flex-col gap-2">
              <label className="text-[9px] tracking-[0.3em] text-white/30 uppercase">Breakdown</label>
              {result.fidelity.criteria.map((c) => (
                <div key={c.name} className="p-3 bg-axiom-surface border border-white/7 rounded">
                  <div className="flex justify-between mb-1.5">
                    <span className="text-[10px] text-white/60">{c.name}</span>
                    <span className="text-[11px] font-mono text-axiom-snow">{c.score}%</span>
                  </div>
                  <div className="h-0.5 bg-axiom-lift rounded overflow-hidden">
                    <div
                      className="h-full rounded transition-all duration-700"
                      style={{
                        width: `${c.score}%`,
                        background: c.score >= 70 ? "#00c9b1" : c.score >= 45 ? "#f0a500" : "#ff5050",
                      }}
                    />
                  </div>
                  <p className="text-[10px] text-white/30 mt-1.5 leading-relaxed">{c.note}</p>
                </div>
              ))}
            </div>

            {/* Suggestions */}
            <div className="flex flex-col gap-2">
              <label className="text-[9px] tracking-[0.3em] text-white/30 uppercase">
                Suggestions — click to apply
              </label>
              {result.fidelity.suggestions.map((s, i) => (
                <button
                  key={i}
                  onClick={() => setRawPrompt((p) => p + ". " + s)}
                  className="text-left p-2.5 bg-axiom-surface border border-white/7 rounded
                             text-[11px] text-white/40 hover:border-amber-500/50 hover:text-axiom-snow
                             hover:bg-amber-500/7 transition leading-relaxed"
                >
                  {s} <span className="text-amber-500 opacity-0 group-hover:opacity-100">↗</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </aside>
    </div>
  );
}
