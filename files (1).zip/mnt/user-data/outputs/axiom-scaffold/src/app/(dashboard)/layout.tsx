import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import { authOptions } from "@/lib/auth";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");

  return (
    <div className="flex h-screen bg-axiom-void overflow-hidden">
      {/* Sidebar */}
      <nav className="w-14 flex flex-col items-center py-4 gap-3
                      border-r border-white/7 bg-axiom-deep flex-shrink-0">
        <div className="font-display text-amber-400 text-xs tracking-widest writing-mode-vertical mb-4">
          AX
        </div>
        {[
          { href: "/studio",   icon: "✦", label: "Studio"  },
          { href: "/gallery",  icon: "⊞", label: "Gallery" },
          { href: "/settings", icon: "⚙", label: "Settings"},
        ].map((item) => (
          <Link
            key={item.href}
            href={item.href}
            title={item.label}
            className="w-9 h-9 flex items-center justify-center rounded border border-white/7
                       text-white/30 hover:border-amber-500/40 hover:text-amber-400
                       hover:bg-amber-500/8 transition text-sm"
          >
            {item.icon}
          </Link>
        ))}
      </nav>

      {/* Main content */}
      <div className="flex-1 overflow-hidden">{children}</div>
    </div>
  );
}
