"use client";

import { useState, useRef, useCallback } from "react";
import { useGallery, useToggleFavorite, useDeleteGeneration } from "@/hooks/useGallery";

export default function GalleryPage() {
  const [favOnly, setFavOnly] = useState(false);
  const { data, fetchNextPage, hasNextPage, isFetchingNextPage } = useGallery(favOnly);
  const toggleFav    = useToggleFavorite();
  const deleteGen    = useDeleteGeneration();
  const observerRef  = useRef<IntersectionObserver | null>(null);

  // Infinite scroll sentinel
  const sentinelRef = useCallback((node: HTMLDivElement | null) => {
    if (observerRef.current) observerRef.current.disconnect();
    if (!node) return;
    observerRef.current = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && hasNextPage && !isFetchingNextPage) {
        fetchNextPage();
      }
    });
    observerRef.current.observe(node);
  }, [fetchNextPage, hasNextPage, isFetchingNextPage]);

  const allItems = data?.pages.flatMap((p) => p.items) ?? [];
  const total    = data?.pages[0]?.pagination.total ?? 0;

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="px-8 py-5 border-b border-white/7 flex items-center justify-between flex-shrink-0">
        <div>
          <p className="text-[10px] tracking-[0.3em] text-amber-500 uppercase mb-1">Gallery</p>
          <h1 className="font-serif italic text-2xl text-axiom-snow">
            Your generations
            <span className="font-mono text-sm text-white/30 ml-3 not-italic">{total}</span>
          </h1>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setFavOnly(false)}
            className={`px-4 py-1.5 rounded-full border text-[11px] font-mono tracking-wider transition
              ${!favOnly ? "border-amber-500/40 text-amber-500 bg-amber-500/8" : "border-white/10 text-white/30 hover:border-white/20"}`}
          >
            All
          </button>
          <button
            onClick={() => setFavOnly(true)}
            className={`px-4 py-1.5 rounded-full border text-[11px] font-mono tracking-wider transition
              ${favOnly ? "border-amber-500/40 text-amber-500 bg-amber-500/8" : "border-white/10 text-white/30 hover:border-white/20"}`}
          >
            ♥ Favorites
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="flex-1 overflow-y-auto p-8">
        {allItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
            <div className="font-display text-7xl text-white/5">EMPTY</div>
            <p className="font-serif italic text-xl text-white/20">No generations yet</p>
            <p className="text-[11px] font-mono text-white/15 max-w-xs leading-relaxed">
              Head to the Studio to create your first image
            </p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
              {allItems.map((item) => (
                <div key={item.id}
                  className="group relative aspect-square rounded-lg overflow-hidden
                             border border-white/7 hover:border-white/20 transition-all
                             hover:shadow-[0_8px_32px_rgba(0,0,0,0.6)]">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={item.thumbnailUrl ?? item.imageUrl}
                    alt={item.rawPrompt}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />

                  {/* Fidelity badge */}
                  {item.fidelityScore != null && (
                    <div className={`absolute top-2 left-2 px-2 py-0.5 rounded text-[9px] font-mono
                      ${item.fidelityScore >= 75 ? "bg-teal-500/80 text-black"
                        : item.fidelityScore >= 50 ? "bg-amber-500/80 text-black"
                        : "bg-red-500/80 text-white"}`}>
                      {item.fidelityScore}%
                    </div>
                  )}

                  {/* Hover overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20
                                  opacity-0 group-hover:opacity-100 transition-opacity
                                  flex flex-col justify-end p-3 gap-1.5">
                    <p className="text-[10px] text-white/70 font-mono leading-tight line-clamp-2">
                      {item.rawPrompt}
                    </p>
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => toggleFav.mutate({ id: item.id, isFavorite: !item.isFavorite })}
                        className={`flex-1 py-1 rounded text-[10px] border transition
                          ${item.isFavorite
                            ? "border-amber-500/50 text-amber-400 bg-amber-500/15"
                            : "border-white/15 text-white/50 hover:border-amber-500/40 hover:text-amber-400"}`}
                      >
                        {item.isFavorite ? "♥" : "♡"}
                      </button>
                      <a
                        href={item.imageUrl}
                        download
                        className="flex-1 py-1 rounded text-[10px] border border-white/15
                                   text-white/50 text-center hover:border-amber-500/40
                                   hover:text-amber-400 transition"
                      >
                        ↓
                      </a>
                      <button
                        onClick={() => {
                          if (confirm("Delete this image?")) deleteGen.mutate(item.id);
                        }}
                        className="py-1 px-2 rounded text-[10px] border border-white/15
                                   text-white/30 hover:border-red-500/40 hover:text-red-400 transition"
                      >
                        ✕
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Infinite scroll sentinel */}
            <div ref={sentinelRef} className="h-10 flex items-center justify-center">
              {isFetchingNextPage && (
                <div className="w-5 h-5 border-2 border-amber-500/30 border-t-amber-500
                                rounded-full animate-spin" />
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
