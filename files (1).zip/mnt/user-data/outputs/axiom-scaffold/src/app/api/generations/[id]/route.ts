import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { deleteImage } from "@/lib/storage";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const userId = (session.user as { id: string }).id;
  const gen = await db.generation.findFirst({ where: { id: params.id, userId } });
  if (!gen) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(gen);
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const userId = (session.user as { id: string }).id;
  const body = await req.json().catch(() => ({}));
  const gen = await db.generation.findFirst({ where: { id: params.id, userId } });
  if (!gen) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const updated = await db.generation.update({
    where: { id: params.id },
    data: { isFavorite: body.isFavorite ?? !gen.isFavorite },
  });
  return NextResponse.json(updated);
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const userId = (session.user as { id: string }).id;
  const gen = await db.generation.findFirst({ where: { id: params.id, userId } });
  if (!gen) return NextResponse.json({ error: "Not found" }, { status: 404 });
  await deleteImage(gen.imageUrl);
  await db.generation.delete({ where: { id: params.id } });
  return NextResponse.json({ deleted: true });
}
