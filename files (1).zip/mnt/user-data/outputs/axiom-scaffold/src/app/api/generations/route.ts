import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

// ── GET /api/generations — paginated gallery ──────────────────
export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  const { searchParams } = new URL(req.url);
  const page    = Math.max(1, parseInt(searchParams.get("page") ?? "1"));
  const limit   = Math.min(50, parseInt(searchParams.get("limit") ?? "20"));
  const favOnly = searchParams.get("favorites") === "true";

  const [items, total] = await Promise.all([
    db.generation.findMany({
      where:   { userId, ...(favOnly && { isFavorite: true }) },
      orderBy: { createdAt: "desc" },
      skip:    (page - 1) * limit,
      take:    limit,
      select: {
        id: true, imageUrl: true, thumbnailUrl: true,
        rawPrompt: true, fidelityScore: true,
        isFavorite: true, createdAt: true,
        strategy: true, imageSize: true,
      },
    }),
    db.generation.count({ where: { userId } }),
  ]);

  return NextResponse.json({
    items,
    pagination: { page, limit, total, pages: Math.ceil(total / limit) },
  });
}
