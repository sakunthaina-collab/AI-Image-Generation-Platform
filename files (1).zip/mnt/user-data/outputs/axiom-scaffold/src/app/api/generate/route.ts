import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { z } from "zod";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { enhancePrompt, checkFidelity } from "@/lib/claude";
import { generateImage } from "@/lib/fal";
import { uploadImageFromUrl } from "@/lib/storage";
import { useCredit } from "@/lib/credits";
import type { FidelityStrategy } from "@/lib/claude";

// ── Request validation ────────────────────────────────────────
const GenerateSchema = z.object({
  rawPrompt:      z.string().min(3).max(500),
  negativePrompt: z.string().max(300).optional(),
  strategy:       z.enum(["PRESERVE", "ENRICH", "STRICT"]).default("PRESERVE"),
  imageSize:      z.enum([
    "square_hd", "landscape_4_3", "landscape_16_9",
    "portrait_4_3", "portrait_16_9",
  ]).default("square_hd"),
  steps: z.number().int().min(4).max(12).default(8),
});

export async function POST(req: NextRequest) {
  // ── Auth guard ──────────────────────────────────────────────
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  // ── Validate input ──────────────────────────────────────────
  const body   = await req.json().catch(() => null);
  const parsed = GenerateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid request", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const { rawPrompt, negativePrompt, strategy, imageSize, steps } = parsed.data;

  try {
    // ── Check & deduct credit ───────────────────────────────
    await useCredit(userId);

    // ── Step 1: Claude enhance prompt ──────────────────────
    const enhanced = await enhancePrompt(rawPrompt, strategy as FidelityStrategy);

    // ── Step 2: Generate image via fal.ai ──────────────────
    const seed = Math.floor(Math.random() * 2147483647);
    const generated = await generateImage({
      prompt:         enhanced.enhanced,
      negativePrompt: negativePrompt ?? enhanced.negative,
      imageSize,
      steps,
      seed,
    });

    // ── Step 3: Move image to R2 ────────────────────────────
    const genId = `gen_${Date.now()}`;
    const { imageUrl, thumbnailUrl } = await uploadImageFromUrl(
      generated.imageUrl,
      userId,
      genId
    );

    // ── Step 4: Fidelity check ──────────────────────────────
    const fidelity = await checkFidelity(rawPrompt, enhanced.enhanced);

    // ── Step 5: Persist to DB ───────────────────────────────
    const generation = await db.generation.create({
      data: {
        userId,
        rawPrompt,
        enhancedPrompt:  enhanced.enhanced,
        negativePrompt:  negativePrompt ?? enhanced.negative,
        strategy:        strategy as FidelityStrategy,
        model:           "fal-ai/flux/schnell",
        imageSize,
        steps,
        seed:            BigInt(seed),
        imageUrl,
        thumbnailUrl,
        fidelityScore:   fidelity.score,
        fidelityData:    fidelity as object,
        genTimeMs:       generated.genTimeMs,
        falRequestId:    generated.requestId,
      },
    });

    // ── Upsert prompt history ───────────────────────────────
    await db.promptHistory.upsert({
      where: {
        userId_rawPrompt_strategy: { userId, rawPrompt, strategy: strategy as FidelityStrategy },
      },
      update: { usedCount: { increment: 1 }, lastUsedAt: new Date(), enhancedPrompt: enhanced.enhanced },
      create: { userId, rawPrompt, enhancedPrompt: enhanced.enhanced, strategy: strategy as FidelityStrategy },
    });

    return NextResponse.json({
      id:              generation.id,
      imageUrl,
      thumbnailUrl,
      enhancedPrompt:  enhanced.enhanced,
      keyAdditions:    enhanced.key_additions,
      fidelity,
      seed,
      genTimeMs:       generated.genTimeMs,
    });

  } catch (err) {
    const message = err instanceof Error ? err.message : "Generation failed";

    // Credit limit error → 429
    if (message.includes("Daily limit")) {
      return NextResponse.json({ error: message }, { status: 429 });
    }

    console.error("[generate] error:", err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
