import { NextAuthOptions } from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import CredentialsProvider from "next-auth/providers/credentials";
import { PrismaAdapter } from "@auth/prisma-adapter";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { db } from "@/lib/db";

export const authOptions: NextAuthOptions = {
  // @ts-ignore — PrismaAdapter types mismatch between next-auth v4 and @auth/prisma-adapter
  adapter: PrismaAdapter(db),
  session: { strategy: "jwt" },

  pages: {
    signIn:  "/login",
    signOut: "/login",
    error:   "/login",
  },

  providers: [
    // ── Google OAuth ────────────────────────────────────────
    GoogleProvider({
      clientId:     process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),

    // ── Email + Password ────────────────────────────────────
    CredentialsProvider({
      name: "credentials",
      credentials: {
        email:    { label: "Email",    type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const parsed = z
          .object({ email: z.string().email(), password: z.string().min(8) })
          .safeParse(credentials);

        if (!parsed.success) return null;

        const user = await db.user.findUnique({
          where: { email: parsed.data.email },
        });

        if (!user?.passwordHash) return null;

        const valid = await bcrypt.compare(
          parsed.data.password,
          user.passwordHash
        );

        return valid ? { id: user.id, email: user.email, name: user.name } : null;
      },
    }),
  ],

  callbacks: {
    // ── Attach user.id & tier to JWT ────────────────────────
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        const dbUser = await db.user.findUnique({
          where:  { id: user.id },
          select: { tier: true },
        });
        token.tier = dbUser?.tier ?? "FREE";
      }
      return token;
    },

    // ── Expose to client session ────────────────────────────
    async session({ session, token }) {
      if (session.user) {
        (session.user as { id?: string }).id   = token.id as string;
        (session.user as { tier?: string }).tier = token.tier as string;
      }
      return session;
    },
  },
};
